package app;

class Node {
    int data;
    Node left;
    Node right;
    int height;

    Node(int key) {
        data = key;
        height = 1;
    }
}

public class AVLtree {
    Node head;

    AVLtree() {
        head = null;
    }

    int height(Node node) {
        return (node == null) ? 0 : node.height;
    }

    int max(int a, int b) {
        return (a > b) ? a : b;
    }

    int getBalance(Node node) {
        return (node == null) ? 0 : height(node.left) - height(node.right);
    }

    Node leftRotate(Node x) {
        Node y = x.right;
        Node T = y.left;

        y.left = x;
        x.right = T;

        x.height = max(height(x.left), height(x.right)) + 1;
        y.height = max(height(y.left), height(y.right)) + 1;

        return y;
    }

    Node rightRotate(Node y) {
        Node x = y.left;
        Node T = x.right;

        x.right = y;
        y.left = T;

        x.height = max(height(x.left), height(x.right)) + 1;
        y.height = max(height(y.left), height(y.right)) + 1;

        return x;
    }

    void insertkey(int key) {
        head = _insert(head, key);
    }

    private Node _insert(Node node, int key) {
        // Node n= new Node(key);
        if (node == null) {
            return new Node(key);
        } else if (key < node.data) {
            node.left = _insert(node.left, key);
        } else if (key > node.data) {
            node.right = _insert(node.right, key);
        } else
            return node;

        node.height = 1 + max(height(node.left), height(node.right));
        int balance = getBalance(node);
        if (balance > 1 && key < node.left.data) {
            return rightRotate(node);
        } else if (balance > 1 && key > node.left.data) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        } else if (balance < -1 && key < node.right.data) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        } else if (balance < -1 && key > node.right.data) {
            return leftRotate(node);
        }

        return node;
    }

    void preOrderTraversal() {
        _avlPreOrderTraversal(head);
    }

    private void _avlPreOrderTraversal(Node root) {
        if (root == null) {
            return;
        }
        System.out.print(root.data + " ");
        _avlPreOrderTraversal(root.left);
        _avlPreOrderTraversal(root.right);
    }

    Node delete(int key, Node node) {
        if (node == null) {
            System.out.println("UnderFlow!");
            return null;
        } else if (key < node.data) {
            return node.left = delete(key, node.left);
        } else if (key > node.data) {
            return node.right = delete(key, node.right);
        } else if (key == node.data) {
            if (node.left == null && node.right == null) {
                return node = null;
            } else if (node.left == null && node.right != null) {
                return node.right;
            } else if (node.right == null && node.left != null) {
                return node.left;
            } else if (node.left != null && node.right != null) {
                Node temp = node.left;
                Node temp2 = node.right;
                node = findMinimumNode(node.right);
                node.left = temp;
                node.right = temp2;
                // delete(key, node)
                return node;
            }
        }
        int balance = getBalance(node);
        if (balance > 1 && key < node.left.data) {
            return rightRotate(node);
        } else if (balance > 1 && key > node.left.data) {
            node.left = leftRotate(node.left);
            return rightRotate(node);
        } else if (balance < -1 && key < node.right.data) {
            node.right = rightRotate(node.right);
            return leftRotate(node);
        } else if (balance < -1 && key > node.right.data) {
            return leftRotate(node);
        }
        return node;

    }

    Node findMinimumNode(Node node) {
        if (node.left == null) {
            return node;
        }
        return findMinimumNode(node.left);
    }

    void inorderTraversal(Node root) {
        if (root == null) {
            return;
        }
        inorderTraversal(root.left);
        System.out.print(root.data + " ");
        inorderTraversal(root.right);
    }
}