package app;

class BinarySearchTree {
    Node head;

    class Node {
        int data;
        Node left;
        Node right;

        Node(int key) {
            this.data = key;
            this.left = null;
            this.right = null;
        }
    }

    BinarySearchTree() {
        head = null;
    }

    void insert(int key) {
        head = _insertData(key, head);
    }

    private Node _insertData(int key, Node root) {
        Node temp = new Node(key);
        if (root == null) {
            root = temp;            
        } else {
            if (key < root.data) {
                root.left = _insertData(key, root.left);
            }
            if (key > root.data) {
            root.right = _insertData(key, root.right);
            }
        }
        return root;
    }

    void inorderTraversal() {
        bstInorderTraversal(head);
    }

    void bstInorderTraversal(Node root) {
        if (root == null) {
            return;
        }
        bstInorderTraversal(root.left);
        System.out.print(root.data + " ");
        bstInorderTraversal(root.right);
    }

    void preOrderTraversal() {
        bstPreOrderTraversal(head);
    }

    void bstPreOrderTraversal(Node root) {
        if (root == null) {
            return;
        }
        System.out.print(root.data);
        bstPreOrderTraversal(root.left);
        bstPreOrderTraversal(root.right);
    }

    void search(int key) {
        _bstSearch(key, head);
    }

    private void _bstSearch(int key, Node root) {
        if (root == null) {
            System.out.print("Element not found");
            return;
        }
        if (root.data == key) {
            System.out.print("Element found");
        } else if (key < root.data) {
            _bstSearch(key, root.left);
        } else if (key > root.data) {
            _bstSearch(key, root.right);
        }
        
    }

    void delete(int key) {
       head =  _deleteElement(key, head);
    }

    private Node _deleteElement(int key, Node root) {
        if (root == null) {
            System.out.println(key + " not found in the BST");
            return null;
        } else if (key < root.data) {
            root.left = _deleteElement(key, root.left);
        } else if (key > root.data) {
            root.right = _deleteElement(key, root.right);
        } else if (key == root.data) {
            if (root.left == null && root.right == null) { //node is leaf node
                root = null;
            } else if (root.left != null && root.right == null) {
                root = root.left;
            } else if (root.right != null && root.left == null) {
                root = root.right;
            } else {
                Node temp = root.left;
                root = findMinimumOnRightSubTree(root.right);
                root.left = temp;
            }
        }
        return root;
    }

    Node findMinimumOnRightSubTree(Node root) {
        if (root.left == null) {
            return root;
        }
        return findMinimumOnRightSubTree(root.left);
    }

}
