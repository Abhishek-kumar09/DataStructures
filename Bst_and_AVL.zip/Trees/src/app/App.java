package app;

public class App {
    public static void main(String[] args) throws Exception {
        BinarySearchTree bst = new BinarySearchTree();
        bst.insert(5);
        bst.insert(3);
        bst.insert(8);
        bst.insert(89);
        bst.insert(4);
        bst.insert(19);       
        bst.preOrderTraversal();
        System.out.println(" ");
        bst.inorderTraversal();
        //bst.search(5);
        //bst.delete(89);
        bst.delete(5);
        //bst.delete(3);
        System.out.println(" ");
        bst.inorderTraversal();
    }
}