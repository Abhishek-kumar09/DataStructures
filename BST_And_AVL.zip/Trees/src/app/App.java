package app;

public class App {
    public static void main(String[] args) throws Exception {
        // BinarySearchTree bst = new BinarySearchTree();
        // bst.insert(5);
        // bst.insert(3);
        // bst.insert(8);
        // bst.insert(89);
        // bst.insert(4);
        // bst.insert(19);
        // bst.preOrderTraversal();
        // System.out.println(" ");
        // bst.inorderTraversal();
        // //bst.search(5);
        // //bst.delete(89);
        // bst.delete(5);
        // //bst.delete(3);
        // System.out.println(" ");
        // bst.inorderTraversal();
        AVLtree avl = new AVLtree();
        avl.insertkey(2);
        avl.insertkey(6);
        avl.insertkey(23);
        avl.insertkey(3);
        avl.insertkey(83);
        avl.insertkey(8);
        avl.insertkey(13);
        // System.out.println(avl.head.data);
        avl.preOrderTraversal();
        System.out.println("");
        avl.inorderTraversal(avl.head);
        avl.delete(8, avl.head);
        System.out.println("");
        avl.inorderTraversal(avl.head);
    }
}